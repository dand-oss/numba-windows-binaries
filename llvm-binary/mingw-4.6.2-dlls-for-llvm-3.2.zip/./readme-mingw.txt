These gcc dlls are needed by llvm

Unzip and place them in your path

---

mingw-4.6.2-dlls-for-llvm-3.2.zip

versions
--------
gcc : ming32 4.6.2
llvm : 3.2svn 08/26/12
