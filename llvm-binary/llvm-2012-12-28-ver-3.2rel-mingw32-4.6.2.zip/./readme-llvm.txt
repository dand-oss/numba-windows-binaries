
llvm-2012-12-28-llvm-3.2rel-mingw32-4.6.2.zip

versions
--------
gcc : ming32 4.6.2
llvm : 3.2rel 12/28/12

this is the "install" directory for llvm.

Unzip and place the "bin" subdir in your path.

THIS IS ONLY NEEDED FOR BUILDING LLVMPY WITH MINGW
